#ifndef REVERSE_H
#define REVERSE_H
#include <string>

class Reverse {
public:
	int reverseDigit(int num);
	std::string reverseString(std::string str);
};
#endif
