#include "Reverse.h"
#include <string>


int Reverse::reverseDigit(int num) {
	static int total = 0;
	if (num) {
		total = total * 10+ num % 10;
		num = num/10;
		reverseDigit(num);
	}
	return total;
}


std::string Reverse::reverseString(std::string str) {
	static std::string newStr="";
	if (!str.empty()) {
		newStr+=str.back();
		str.pop_back();
		reverseString(str);
	}
	return newStr;
	
	
}
